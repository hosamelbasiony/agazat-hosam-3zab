#!/bin/bash

# composer install -o --working-dir="$WORKDIR"/application

php-fpm
